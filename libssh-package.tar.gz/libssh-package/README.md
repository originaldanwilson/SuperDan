# libssh Package for RedHat 8

This package contains libssh 0.10.6 compiled on Ubuntu 24.04.

**WARNING**: This may not work on RedHat 8 due to library incompatibilities between Ubuntu and RedHat. If it doesn't work, you'll need to compile libssh from source on your RedHat box.

## Installation

```bash
cd libssh-package
./install.sh
```

Then add to your `~/.bashrc`:
```bash
export LD_LIBRARY_PATH=$HOME/.local/lib:$LD_LIBRARY_PATH
export PKG_CONFIG_PATH=$HOME/.local/lib/pkgconfig:$PKG_CONFIG_PATH
```

Run: `source ~/.bashrc`

## Verify

```bash
pkg-config --modversion libssh
```

## If this doesn't work

You'll need to compile from source on RedHat:

1. Install cmake locally (no sudo needed):
```bash
cd ~
wget https://github.com/Kitware/CMake/releases/download/v3.27.9/cmake-3.27.9-linux-x86_64.tar.gz
tar -xzf cmake-3.27.9-linux-x86_64.tar.gz
export PATH=$HOME/cmake-3.27.9-linux-x86_64/bin:$PATH
```

2. Build libssh:
```bash
wget https://github.com/canonical/libssh/archive/refs/tags/libssh-0.10.6.tar.gz
tar -xzf libssh-0.10.6.tar.gz
cd libssh-libssh-0.10.6
mkdir build && cd build
cmake .. -DCMAKE_INSTALL_PREFIX=$HOME/.local
make -j$(nproc)
make install
```
