#!/bin/bash
# Installation script for libssh (compiled on Ubuntu 24.04)
# WARNING: This may not work on RedHat 8 due to library incompatibilities

INSTALL_DIR="$HOME/.local"

echo "Installing libssh to $INSTALL_DIR"

# Create directories
mkdir -p "$INSTALL_DIR/lib"
mkdir -p "$INSTALL_DIR/include"
mkdir -p "$INSTALL_DIR/lib/pkgconfig"

# Copy files
cp -v libssh.so* "$INSTALL_DIR/lib/"
cp -rv include/libssh "$INSTALL_DIR/include/"
cp -v pkgconfig/libssh.pc "$INSTALL_DIR/lib/pkgconfig/"

# Update pkgconfig file
sed -i "s|/usr|$INSTALL_DIR|g" "$INSTALL_DIR/lib/pkgconfig/libssh.pc"

echo ""
echo "Installation complete!"
echo ""
echo "Add these lines to your ~/.bashrc:"
echo "export LD_LIBRARY_PATH=\$HOME/.local/lib:\$LD_LIBRARY_PATH"
echo "export PKG_CONFIG_PATH=\$HOME/.local/lib/pkgconfig:\$PKG_CONFIG_PATH"
echo ""
echo "Then run: source ~/.bashrc"
